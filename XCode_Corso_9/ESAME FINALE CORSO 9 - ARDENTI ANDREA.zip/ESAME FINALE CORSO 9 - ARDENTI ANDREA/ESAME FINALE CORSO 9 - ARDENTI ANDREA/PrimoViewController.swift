//
//  PrimoViewController.swift
//  ESAME FINALE CORSO 9 - ARDENTI ANDREA
//
//  Created by Andrea Ardenti on 16/04/2019.
//  Copyright © 2019 Andrea Ardenti. All rights reserved.
//

import UIKit

class PrimoViewController: UIViewController {

    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var descriptor1: UILabel!
    @IBOutlet weak var discount1: UILabel!
    @IBOutlet weak var price1: UILabel!
    @IBOutlet weak var name2: UILabel!
    @IBOutlet weak var descriptor2: UILabel!
    @IBOutlet weak var discount2: UILabel!
    @IBOutlet weak var price2: UILabel!
    @IBOutlet weak var name3: UILabel!
    @IBOutlet weak var descriptor3: UILabel!
    @IBOutlet weak var discount3: UILabel!
    @IBOutlet weak var price3: UILabel!
    @IBOutlet weak var acq_1: UIButton!
    @IBOutlet weak var acq_2: UIButton!
    @IBOutlet weak var acq_3: UIButton!
  
    @IBOutlet weak var acquistato_1: UILabel!
    @IBOutlet weak var acquistato_2: UILabel!
    @IBOutlet weak var acquistato_3: UILabel!
    
    var boat_1: Boat?
    var boat_2: Boat?
    var boat_3: Boat?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("PrimoViewController: viewDidLoad")

        self.boat_1 = Boat.init(name: "I 4 mari", descriptor: "Cabinato", discount: 10, price: 40000)
        self.boat_1?.finalPrice()
        
        self.boat_2 = Boat.init(name: "Siamo a mare", descriptor: "A Cielo", discount: 10, price: 30000)

        self.boat_2?.finalPrice()

        self.boat_3 = Boat.init(name: "La zattera", descriptor: "Barca a Remi", discount: 10, price: 10000)
        
        self.boat_3?.finalPrice()

        
        self.name1.text = self.boat_1?.name
        self.descriptor1.text = self.boat_1?.descriptor
        if let discount_1 = self.boat_1?.discount{
            self.discount1.text = String(discount_1)
        }
        if let price_1 = self.boat_1?.price{
            self.price1.text = String(price_1)
        }
        
        self.name2.text = self.boat_2?.name
        self.descriptor2.text = self.boat_2?.descriptor
        if let discount_2 = self.boat_2?.discount{
            self.discount2.text = String(discount_2)
        }
        if let price_2 = self.boat_2?.price{
            self.price2.text = String(price_2)
        }
        
        self.name3.text = self.boat_3?.name
        self.descriptor3.text = self.boat_3?.descriptor
        if let discount_3 = self.boat_3?.discount{
            self.discount3.text = String(discount_3)
        }
        if let price_3 = self.boat_3?.price{
            self.price3.text = String(price_3)
        }
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("PrimoViewController: viewWillAppear")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("PrimoViewController: viewDidAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        print("PrimoViewController: viewWillDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        print("PrimoViewController: viewDidDisappear")
    }
    
    @IBAction func changeValueAction_1(_ sender: Any) {
        print("Button Tapped: acquistato_1")
        self.acquistato_1.isHidden = false
        self.acq_1.isHidden = true
    }
    
    @IBAction func changeValueAction_2(_ sender: Any) {
        print("Button Tapped: acquistato_2")
        self.acquistato_2.isHidden = false
        self.acq_2.isHidden = true
    }
    
    @IBAction func changeValueAction_3(_ sender: Any) {
        print("Button Tapped: acquistato_3")
        self.acquistato_3.isHidden = false
        self.acq_3.isHidden = true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
