//
//  Boat.swift
//  ESAME FINALE CORSO 9 - ARDENTI ANDREA
//
//  Created by Andrea Ardenti on 16/04/2019.
//  Copyright © 2019 Andrea Ardenti. All rights reserved.
//

import UIKit

class Boat: NSObject {
    
    var name: String?
    var descriptor: String?
    var discount: Double?
    var price: Double?
    
    init(name: String?, descriptor: String?, discount: Double?, price: Double?) {
        self.name = name
        self.descriptor = descriptor
        self.discount = discount
        self.price = price
    }
    
    func finalPrice() {
        if((self.discount) != nil) {
            self.price = self.price! - ((self.price! * self.discount!) / 100)
        }
    }

}
