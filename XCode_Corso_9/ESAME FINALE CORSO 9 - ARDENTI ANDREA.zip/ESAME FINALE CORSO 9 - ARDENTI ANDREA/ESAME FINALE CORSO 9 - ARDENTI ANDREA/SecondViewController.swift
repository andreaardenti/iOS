//
//  SecondViewController.swift
//  ESAME FINALE CORSO 9 - ARDENTI ANDREA
//
//  Created by Andrea Ardenti on 16/04/2019.
//  Copyright © 2019 Andrea Ardenti. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var thankYou: UITextField!
    @IBOutlet weak var buy: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("SecondViewController: viewDidLoad")

        self.thankYou.text = "GRAZIE!"
        self.buy.text = "...per aver acquistato da noi..."
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        print("SecondViewController: viewWillAppear")
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        print("SecondViewController: viewDidAppear")
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        print("SecondViewController: viewWillDisappear")
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        print("SecondViewController: viewDidDisappear")
        
    }
    @IBAction func closeSVC(_ sender: Any) {
        print("SecondViewController Button Tapped: CloseVC Pressed")
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
